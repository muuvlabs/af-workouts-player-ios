//
//
//  WorkoutPlayerCore.h
//
//  Created by Cristian Barril on 04/01/2023
//
//

#import <Foundation/Foundation.h>

//! Project version number for WorkoutPlayerCore.
FOUNDATION_EXPORT double WorkoutPlayerCoreVersionNumber;

//! Project version string for WorkoutPlayerCore.
FOUNDATION_EXPORT const unsigned char WorkoutPlayerCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WorkoutPlayerCore/PublicHeader.h>


